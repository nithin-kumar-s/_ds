package com.example.LabCycle08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabCycle08Application {

	public static void main(String[] args) {
		SpringApplication.run(LabCycle08Application.class, args);
	}

}
