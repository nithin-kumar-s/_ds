package com.example.mca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McaApplicationTests {

	@Test
	void contextLoads() {
	}

}
