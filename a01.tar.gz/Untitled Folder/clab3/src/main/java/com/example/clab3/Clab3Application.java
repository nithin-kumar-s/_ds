package com.example.clab3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clab3Application {

	public static void main(String[] args) {
		SpringApplication.run(Clab3Application.class, args);
	}

}
